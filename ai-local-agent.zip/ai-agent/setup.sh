#!/usr/bin/env bash
# Setup AI Local Agent di GitHub Codespaces
set -e

MODEL="${AGENT_MODEL:-qwen3-coder:4b}"

echo "=============================================="
echo "  Setup AI Local Agent (Qwen3-Coder via Ollama)"
echo "=============================================="

# 1. Install Ollama kalau belum ada
if ! command -v ollama &> /dev/null; then
    echo "[1/4] Menginstall Ollama..."
    curl -fsSL https://ollama.com/install.sh | sh
else
    echo "[1/4] Ollama sudah terinstall, skip."
fi

# 2. Jalankan Ollama server di background (kalau belum jalan)
if ! pgrep -x "ollama" > /dev/null; then
    echo "[2/4] Menjalankan Ollama server di background..."
    nohup ollama serve > /tmp/ollama.log 2>&1 &
    sleep 3
else
    echo "[2/4] Ollama server sudah berjalan, skip."
fi

# 3. Pull model Qwen3-Coder 4B
echo "[3/4] Mengunduh model '$MODEL' (bisa memakan waktu beberapa menit)..."
ollama pull "$MODEL" || {
    echo "!! Gagal pull '$MODEL'. Cek nama tag yang tersedia dengan: ollama search qwen"
    echo "!! Alternatif umum: qwen2.5-coder:3b, qwen2.5-coder:7b"
}

# 4. Install dependensi Python
echo "[4/4] Menginstall dependensi Python..."
pip install -r requirements.txt --break-system-packages 2>/dev/null || pip install -r requirements.txt

echo ""
echo "Setup selesai! Jalankan agent dengan:"
echo "    python3 agent.py"
echo ""
