#!/usr/bin/env python3
"""
AI Local Agent CLI - Codespaces Edition
Model: Qwen3-Coder 4B (via Ollama, 100% lokal)

Fitur:
- System prompt bisa diatur lewat prompt.md
- Baca & tulis file di workspace
- Jalankan command shell langsung dari chat
- Tampilan CLI berwarna (rich)
"""

import os
import sys
import json
import subprocess
from pathlib import Path

try:
    import requests
    from rich.console import Console
    from rich.panel import Panel
    from rich.markdown import Markdown
    from rich.prompt import Prompt
    from rich import box
except ImportError:
    print("Dependensi belum terinstall. Jalankan: pip install -r requirements.txt")
    sys.exit(1)

# ----------------------------------------------------------------------------
# Konfigurasi
# ----------------------------------------------------------------------------
OLLAMA_URL = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
MODEL = os.environ.get("AGENT_MODEL", "qwen3-coder:4b")
PROMPT_FILE = Path(__file__).parent / "prompt.md"
WORKDIR = Path(os.environ.get("AGENT_WORKDIR", os.getcwd())).resolve()
MAX_TOOL_ITERS = 8
COMMAND_TIMEOUT = 120

console = Console()

BANNER = r"""
[bold cyan] █████╗ ██╗       █████╗  ██████╗ ███████╗███╗   ██╗████████╗[/]
[bold cyan]██╔══██╗██║      ██╔══██╗██╔════╝ ██╔════╝████╗  ██║╚══██╔══╝[/]
[bold cyan]███████║██║█████╗███████║██║  ███╗█████╗  ██╔██╗ ██║   ██║   [/]
[bold cyan]██╔══██║██║╚════╝██╔══██║██║   ██║██╔══╝  ██║╚██╗██║   ██║   [/]
[bold cyan]██║  ██║██║      ██║  ██║╚██████╔╝███████╗██║ ╚████║   ██║   [/]
[bold cyan]╚═╝  ╚═╝╚═╝      ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═══╝   ╚═╝   [/]
"""

# ----------------------------------------------------------------------------
# Tool definitions (format function-calling ala OpenAI, didukung Ollama)
# ----------------------------------------------------------------------------
TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Baca isi sebuah file di dalam workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path file relatif dari root workspace"}
                },
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Buat atau timpa (overwrite) isi sebuah file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path file relatif dari root workspace"},
                    "content": {"type": "string", "description": "Isi lengkap yang akan ditulis ke file"},
                },
                "required": ["path", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_dir",
            "description": "Lihat isi sebuah folder (nama file & subfolder).",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path folder, default '.' (root workspace)"}
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "run_command",
            "description": "Jalankan perintah shell/terminal langsung di workspace dan kembalikan stdout/stderr/exit code.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Perintah shell yang akan dieksekusi"}
                },
                "required": ["command"],
            },
        },
    },
]


# ----------------------------------------------------------------------------
# Implementasi tool
# ----------------------------------------------------------------------------
def _safe_path(path: str) -> Path:
    return (WORKDIR / path).resolve()


def tool_read_file(path: str) -> str:
    try:
        p = _safe_path(path)
        if not p.exists():
            return f"ERROR: file '{path}' tidak ditemukan"
        text = p.read_text(encoding="utf-8", errors="replace")
        if len(text) > 20000:
            text = text[:20000] + "\n...(dipotong, file terlalu panjang)"
        return text
    except Exception as e:
        return f"ERROR: {e}"


def tool_write_file(path: str, content: str) -> str:
    try:
        p = _safe_path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"OK: file ditulis ke '{path}' ({len(content)} bytes)"
    except Exception as e:
        return f"ERROR: {e}"


def tool_list_dir(path: str = ".") -> str:
    try:
        p = _safe_path(path)
        if not p.exists():
            return f"ERROR: folder '{path}' tidak ditemukan"
        items = []
        for entry in sorted(p.iterdir()):
            prefix = "[DIR] " if entry.is_dir() else "      "
            items.append(prefix + entry.name)
        return "\n".join(items) if items else "(folder kosong)"
    except Exception as e:
        return f"ERROR: {e}"


def tool_run_command(command: str) -> str:
    try:
        result = subprocess.run(
            command,
            shell=True,
            cwd=WORKDIR,
            capture_output=True,
            text=True,
            timeout=COMMAND_TIMEOUT,
        )
        parts = []
        if result.stdout.strip():
            parts.append(result.stdout.strip())
        if result.stderr.strip():
            parts.append("[stderr]\n" + result.stderr.strip())
        parts.append(f"[exit code: {result.returncode}]")
        return "\n".join(parts)
    except subprocess.TimeoutExpired:
        return f"ERROR: command melebihi timeout ({COMMAND_TIMEOUT}s)"
    except Exception as e:
        return f"ERROR: {e}"


DISPATCH = {
    "read_file": lambda a: tool_read_file(a.get("path", "")),
    "write_file": lambda a: tool_write_file(a.get("path", ""), a.get("content", "")),
    "list_dir": lambda a: tool_list_dir(a.get("path", ".")),
    "run_command": lambda a: tool_run_command(a.get("command", "")),
}


# ----------------------------------------------------------------------------
# UI helpers
# ----------------------------------------------------------------------------
def load_system_prompt() -> str:
    if PROMPT_FILE.exists():
        return PROMPT_FILE.read_text(encoding="utf-8")
    return "Kamu adalah AI coding agent yang membantu di terminal."


def print_banner():
    console.print(BANNER)
    console.print(
        Panel.fit(
            f"[bold green]AI Local Agent[/bold green]  •  Model: [yellow]{MODEL}[/yellow]  •  "
            f"Workdir: [cyan]{WORKDIR}[/cyan]\n"
            "[dim]Ketik pesan lalu Enter  •  /help bantuan  •  /reload muat ulang prompt.md  •  /exit keluar[/dim]",
            border_style="magenta",
            box=box.ROUNDED,
        )
    )


def print_tool_call(name: str, args: dict):
    console.print(
        Panel(
            f"[bold]{name}[/bold]({json.dumps(args, ensure_ascii=False)})",
            title="🔧 Tool Call",
            border_style="yellow",
            box=box.ROUNDED,
        )
    )


def print_tool_result(name: str, result: str):
    txt = result if len(result) < 2500 else result[:2500] + "\n...(dipotong)"
    console.print(
        Panel(txt, title=f"✅ Hasil: {name}", border_style="green", box=box.ROUNDED)
    )


def print_error(msg: str):
    console.print(Panel(msg, title="❌ Error", border_style="red", box=box.ROUNDED))


# ----------------------------------------------------------------------------
# Komunikasi dengan Ollama
# ----------------------------------------------------------------------------
def chat_once(messages: list) -> dict:
    payload = {"model": MODEL, "messages": messages, "tools": TOOLS, "stream": False}
    resp = requests.post(f"{OLLAMA_URL}/api/chat", json=payload, timeout=600)
    resp.raise_for_status()
    return resp.json()


def run_agent_turn(messages: list):
    for _ in range(MAX_TOOL_ITERS):
        try:
            with console.status("[bold cyan]AI sedang berpikir...[/bold cyan]", spinner="dots"):
                data = chat_once(messages)
        except requests.exceptions.ConnectionError:
            print_error(
                f"Tidak bisa konek ke Ollama di {OLLAMA_URL}.\n"
                "Pastikan Ollama sudah jalan: [bold]ollama serve[/bold] "
                f"dan model sudah di-pull: [bold]ollama pull {MODEL}[/bold]"
            )
            return
        except Exception as e:
            print_error(str(e))
            return

        msg = data.get("message", {})
        tool_calls = msg.get("tool_calls")

        if tool_calls:
            messages.append(msg)
            for call in tool_calls:
                fn = call.get("function", {})
                name = fn.get("name")
                args = fn.get("arguments", {})
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except Exception:
                        args = {}
                print_tool_call(name, args)
                handler = DISPATCH.get(name)
                result = handler(args) if handler else f"ERROR: tool '{name}' tidak dikenal"
                print_tool_result(name, result)
                messages.append({"role": "tool", "content": result, "name": name})
            continue
        else:
            content = msg.get("content", "") or "(tidak ada jawaban)"
            messages.append({"role": "assistant", "content": content})
            console.print(
                Panel(Markdown(content), title="🤖 AI Agent", border_style="cyan", box=box.ROUNDED)
            )
            return

    print_error("Batas maksimum iterasi tool tercapai (kemungkinan looping).")


# ----------------------------------------------------------------------------
# Main loop
# ----------------------------------------------------------------------------
def main():
    print_banner()
    system_prompt = load_system_prompt()
    messages = [{"role": "system", "content": system_prompt}]

    while True:
        try:
            user_input = Prompt.ask("[bold magenta]Anda[/bold magenta]")
        except (KeyboardInterrupt, EOFError):
            console.print("\n[yellow]Sampai jumpa![/yellow]")
            break

        cmd = user_input.strip()
        if not cmd:
            continue
        if cmd in ("/exit", "/quit"):
            console.print("[yellow]Sampai jumpa![/yellow]")
            break
        if cmd == "/help":
            console.print(
                Panel(
                    "/help    - tampilkan bantuan\n"
                    "/reload  - muat ulang prompt.md tanpa restart\n"
                    "/clear   - hapus histori percakapan\n"
                    "/exit    - keluar dari agent",
                    title="Bantuan",
                    border_style="blue",
                    box=box.ROUNDED,
                )
            )
            continue
        if cmd == "/reload":
            system_prompt = load_system_prompt()
            messages[0] = {"role": "system", "content": system_prompt}
            console.print("[green]prompt.md berhasil dimuat ulang.[/green]")
            continue
        if cmd == "/clear":
            messages = [{"role": "system", "content": system_prompt}]
            console.print("[green]Histori percakapan dihapus.[/green]")
            continue

        messages.append({"role": "user", "content": user_input})
        run_agent_turn(messages)


if __name__ == "__main__":
    main()
