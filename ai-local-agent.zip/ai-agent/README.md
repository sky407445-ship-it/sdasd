# 🤖 AI Local Agent — Codespaces Edition

Agent AI coding **100% lokal** yang berjalan di dalam GitHub Codespaces, memakai
model **Qwen3-Coder 4B** lewat [Ollama](https://ollama.com) — tidak ada data yang
dikirim ke API eksternal.

Fitur:
- ✅ System prompt bisa diatur bebas lewat `prompt.md`
- ✅ Tampilan CLI berwarna & rapi (pakai library `rich`)
- ✅ AI bisa membaca file (`read_file`) dan folder (`list_dir`)
- ✅ AI bisa menulis/membuat file (`write_file`)
- ✅ AI bisa menjalankan command apapun langsung di terminal (`run_command`)

## 🚀 Cara Pakai di GitHub Codespaces

1. Upload/extract folder `ai-agent` ini ke dalam Codespace kamu.
2. Buka terminal, masuk ke folder tersebut:
   ```bash
   cd ai-agent
   chmod +x setup.sh
   ./setup.sh
   ```
   Script ini otomatis:
   - Install Ollama
   - Menjalankan `ollama serve` di background
   - Mengunduh model `qwen3-coder:4b`
   - Menginstall dependensi Python (`rich`, `requests`)

3. Jalankan agent:
   ```bash
   python3 agent.py
   ```

4. Mulai chat! Contoh:
   ```
   Anda: baca file package.json terus jelasin dependensinya
   Anda: buatkan file hello.py yang print "Hello World" lalu jalankan
   Anda: cek status git dan commit semua perubahan
   ```

## ⚙️ Mengatur Kepribadian AI (`prompt.md`)

Edit file `prompt.md` sesuka hati — ini adalah system prompt yang menentukan
gaya bicara, aturan, dan batasan AI. Setelah edit, cukup ketik `/reload` di
dalam CLI agent (tanpa perlu restart program).

## 🔧 Konfigurasi (opsional, lewat environment variable)

| Variable         | Default                     | Keterangan                          |
|------------------|------------------------------|--------------------------------------|
| `AGENT_MODEL`    | `qwen3-coder:4b`             | Nama tag model Ollama yang dipakai   |
| `OLLAMA_HOST`    | `http://localhost:11434`     | Alamat Ollama server                 |
| `AGENT_WORKDIR`  | direktori saat ini            | Root folder yang bisa diakses agent  |

Contoh:
```bash
AGENT_MODEL="qwen2.5-coder:7b" python3 agent.py
```

## 📌 Perintah dalam CLI

| Perintah   | Fungsi                                   |
|------------|-------------------------------------------|
| `/help`    | Tampilkan bantuan                         |
| `/reload`  | Muat ulang `prompt.md` tanpa restart      |
| `/clear`   | Hapus histori percakapan                  |
| `/exit`    | Keluar dari agent                         |

## ⚠️ Catatan Keamanan

`run_command` mengeksekusi perintah shell **langsung tanpa konfirmasi**, sesuai
permintaan desain agent ini. Jalankan di lingkungan Codespaces yang terisolasi
dan jangan sambungkan ke workspace produksi yang sensitif.

## 🧩 Struktur File

```
ai-agent/
├── agent.py          # Program utama (CLI + tool-calling loop)
├── prompt.md          # System prompt yang bisa diedit
├── requirements.txt   # Dependensi Python
├── setup.sh            # Script instalasi otomatis
└── README.md           # Dokumentasi ini
```
